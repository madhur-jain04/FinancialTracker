// frontend/src/components/AuthForm.jsx
import React, { useState } from 'react';
// axios will be used here to talk to POST /api/auth/login or /register

export default function AuthForm({ API_BASE_URL, onLogin }) {
    const [isLogin, setIsLogin] = useState(true);
    const [username, setUsername] = useState('user@test.com'); // Pre-fill for quick testing
    const [password, setPassword] = useState('password123');
    const [loading, setLoading] = useState(false);

    const handleSubmit = (e) => {
        e.preventDefault();
        setLoading(true);

        // --- MOCK LOGIN FOR NOW ---
        // REPLACE THIS WITH ACTUAL AXIOS CALLS TO YOUR BACKEND API/auth/login
        setTimeout(() => {
            console.log(`Attempting ${isLogin ? 'Login' : 'Register'} for ${username}`);
            // On successful auth, call onLogin and pass the user object
            onLogin({ id: 'mock-user-123', username: username }); 
            setLoading(false);
        }, 1500);
        // --- END MOCK ---
    };

    return (
        <div className="bg-white p-8 rounded-xl shadow-2xl w-full max-w-sm border border-indigo-200">
            <h2 className="text-3xl font-extrabold text-indigo-700 mb-6 text-center">
                {isLogin ? 'Sign In' : 'Register'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700">Username (or Email)</label>
                    <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                        className="mt-1 block w-full p-2 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700">Password</label>
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="mt-1 block w-full p-2 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500"
                    />
                </div>
                <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-2 px-4 rounded-md text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 transition shadow-lg"
                >
                    {loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Sign Up')}
                </button>
            </form>
            <div className="mt-6 text-center">
                <button
                    onClick={() => setIsLogin(!isLogin)}
                    className="text-sm text-indigo-600 hover:text-indigo-800"
                >
                    {isLogin ? "Need an account? Sign up" : "Already have an account? Sign in"}
                </button>
            </div>
        </div>
    );
}